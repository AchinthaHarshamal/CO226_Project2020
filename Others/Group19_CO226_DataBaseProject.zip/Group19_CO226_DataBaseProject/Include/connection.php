<?php
			//change this part
			///////////////////////////
			$username = "root";
	    	$password = "";
	    	$port = 3308;
	    	//////////////////////////


	    	$database = "channeling_system";
	    	$connection= mysqli_connect("localhost", $username, $password, $database,$port);
	
	
	if(mysqli_connect_errno()){
		die('Database connection faild'.mysqli_connect_error());
	}else{
		//echo "Connect";
	}


?>