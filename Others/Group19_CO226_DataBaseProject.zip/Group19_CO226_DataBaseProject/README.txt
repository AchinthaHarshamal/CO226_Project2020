/// i)   Intialy run the 'DatabaseFile/CO226ProjectPopulatedDatabase_Group19.sql' on your database
/// ii)  Then open the 'Include/connectoin.php' and give the values for
			$username
			$password
			$port 
				 and save the file.

/// iii) Start with 'Home.php' .

E/17/018
E/17/090
E/17/168

	~~~Enjoy the WebSite~~~
