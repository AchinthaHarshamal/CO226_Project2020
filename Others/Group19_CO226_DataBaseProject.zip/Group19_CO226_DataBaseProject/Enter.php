<html>
    <head><title>Lab01</title>
        <link href="sty.css" type="text/css" rel="stylesheet" />
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    </head>
    <body>
      
        <h1>Channel Center</h1></div>
        <hr width="100%" align="left" style="height:2px;border-width:0;color:rgb(0, 44, 61);background-color:rgb(4, 100, 124)">
        <br>
        <h2>Enter Channel Center Details:</h2>

       
        <hr width="100%" align="left" style="height:2px;border-width:0;color:rgb(0, 44, 61);background-color:rgb(4, 100, 124)">
        
        <div class="main-block">
     
            <form action="/">
              <div class="title">
                <i class="fas fa-pencil-alt"></i> 
                <h3>Enter here</h3>
              </div>
              <div class="colums">
                <div class="item">
                  <label for="CName">Center Name<span>*</span></label>
                  <input id="CName" type="text" name="CName" required/>
                </div>
      
                <div class="item">
                  <label for="Email">Email<span>*</span></label>
                  <input id="Email" type="text" name="Email" required/>
                </div>
                <div class="item">
                  <label for="address">Address<span>*</span></label>
                  <input id="address" type="text"   name="address" required/>
                </div>
                <div class="item">
                  <label for="PNumber">Phone number1<span>*</span></label>
                  <input id="PNumber1" type="text"  name="PNumber1" required/>
                </div>
                <div class="item">
                  <label for="PNumber2">Phone number2<span>*</span></label>
                  <input id="PNumber2" type="text"   name="PNumber2" required/>
                </div>
                <div class="item">
                  <label for="Facilities">Facilities<span>*</span></label>
                  <input id="Facilities" type="text" name="Facilities" required/>
                </div>
                
              </div>
              <!--
              <div class="info">
                <input class="CenteN" type="text" name="CenteN" placeholder="Center Name">
                <input type="text" name="name" placeholder="Email">
                <input type="text" name="name" placeholder="Phone number1">
                <input type="text" name="name" placeholder="Phone number2">
                <input type="textarea" name="name" placeholder="Location">
                <input type="textarea" name="name" placeholder="Facilities">
               
              </div>-->
      
              </div>
              <button type="submit" href="/">Submit</button>
            </form>
          </div>
        </body>

    </body>

</html>